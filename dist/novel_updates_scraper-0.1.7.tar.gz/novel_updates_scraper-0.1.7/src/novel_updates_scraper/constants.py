BASE_URL="https://www.novelupdates.com/"


